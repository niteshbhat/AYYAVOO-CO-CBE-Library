   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2021 AYYAVOO&CO CBE Library Management System |<a href="https://niteshbhat.github.io/" target="_blank"  > Designed by : Nitesh Bhat</a> 
                </div>

            </div>
        </div>
    </section>